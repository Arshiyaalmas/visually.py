# Assistant-for-blind

You can download the yolov3 pretrained weights by clicking [here](https://pjreddie.com/media/files/yolov3.weights)
